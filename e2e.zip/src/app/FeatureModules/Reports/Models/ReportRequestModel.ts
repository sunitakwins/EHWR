export class ReportRequestModel{ 
      PageNo:number=1;
      PageSize:number=100;
      SearchValue:string="";
      SortColumn:string="";
      SortOrder:string="";
}