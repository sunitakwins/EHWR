export class UpdateEmployeesRequestModel {
  PageNo = -1;
  PageSize = 20;
  SearchValue:string = "";
  SortColumn:string="";
  SortOrder:string = "Asc";
}
