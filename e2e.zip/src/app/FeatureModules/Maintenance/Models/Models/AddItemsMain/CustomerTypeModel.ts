export class CustomerTypeModel {
  CategoryName: string;
}
