export class AddItemsMainModel {
  itemId: number;
  itemName: string;
  itemType: number;
  itemParts: number;
  itemPartName: string;
  itemTypeName: string;
  itemDescription: string;
  customerType: number;
  customerTypeName: string;
  price_exTax: number;
  effectiveDate = '';
  totalPrice: number;
}
