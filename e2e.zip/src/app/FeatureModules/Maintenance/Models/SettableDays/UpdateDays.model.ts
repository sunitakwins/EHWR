export class UpdateSettableDays{
    "systemSettingId": number = 1;
    "settingDays": number;
    "modifiedBy": string = "Michael";
}