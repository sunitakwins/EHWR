import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-Maintenance',
  templateUrl: './Maintenance.component.html',
  styleUrls: ['./Maintenance.component.scss']
})
export class MaintenanceComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
