export class EmployeeRequestModel{
    public PageNo:string = '1';
    public PageSize:string = '50';
    public SearchValue:string = '';
    public SortColumn:string = '';
    public SortOrder:string='';
} 