export class ContactListModel{
    "customerId":number;
    "customerContactId": number ;
    "contactName": string;
    "email": string;
    "phoneNo": number
}