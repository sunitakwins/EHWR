export class DashboardRequestModel{
    SearchValue: string;
}