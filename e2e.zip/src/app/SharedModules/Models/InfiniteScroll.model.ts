export class InfiniteScrollModel{
    throttle = 50;
    scrollDistance = 5;
    scrollUpDistance = 5;
}