
// Chart 1
export type ChartOptions = {
    // series: ApexAxisChartSeries;
    // chart: ApexChart;
    // xaxis: ApexXAxis;
    // yaxis: ApexYAxis | ApexYAxis[];
    // title: ApexTitleSubtitle;
    // labels: string[];
    // stroke: any; 
    // dataLabels: any; 
    // fill: ApexFill;
    // tooltip: ApexTooltip;
  };
  
  // Chart 2
  export type ChartOptions2 = {
    // series: ApexAxisChartSeries;
    // chart: ApexChart;
    // xaxis: ApexXAxis;
    // dataLabels: ApexDataLabels;
    // grid: ApexGrid;
    // stroke: ApexStroke;
    // title: ApexTitleSubtitle;
  };
  