import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-Customers',
  templateUrl: './Customers.component.html',
  styleUrls: ['./Customers.component.scss']
})
export class CustomersComponent implements OnInit {

  constructor()
   {
     
    }
  
  ngOnInit() {
  }

}
