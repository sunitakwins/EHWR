export class SuburbRequestModel{
    SearchValue:string ='';
    SortColumn: string ='suburb';
    SortOrder: string = 'asc'
    }