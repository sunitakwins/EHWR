export class CustomerListModel{
    'customerId': number ;
    "customerName":string ;
    "email": string;
    "phoneNo": number;
    "totalRows": number;
    'totalCustomerWiseJobsCount': number;
}