export class CusInvoicesList{
    "invoiceId": number;
    "dueDate": Date;
    "sendDate":Date;
    "amountDue": number;
    "amountPaid": number;
    "status": string
}