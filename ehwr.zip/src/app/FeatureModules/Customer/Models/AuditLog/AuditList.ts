export class AuditList{
    "customerId": number;
    "customerName": String;
    "lastModifiedByDate": Date;
    "lastModifiedBy":string;
    "customerModule": string;
    "jobOrderId": number;
    "invoiceId": number;
    "paymentId": number;
    "customerContactId": number
}