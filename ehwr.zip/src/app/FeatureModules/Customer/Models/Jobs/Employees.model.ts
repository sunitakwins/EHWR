export class EmployeesModel{
    employeeId:number= 1;
    employeeName:string;
}