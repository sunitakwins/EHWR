export class EmployeeRequestModel{
     IsActive:boolean = true; 
     PageNo:string = '1';
     PageSize:string = '50';
     SearchValue:string = '';
     SortColumn:string = '';
     SortOrder:string='';
} 