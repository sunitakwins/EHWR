export class ContactModel {
    "customerId": number;
    // "salutation": number;
    "firstName": string;
    "lastName": string;
    "defaultEmail": boolean;
    "email": string;
    "phoneNo": string = '';
    "phoneBusiness":string = '';
    "createdBy": string;
    }
    