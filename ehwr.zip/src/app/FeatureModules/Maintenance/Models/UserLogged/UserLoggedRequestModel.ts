export class UserLoggedRequestModel{
PageNo:number=1
PageSize:number=100
SearchValue:string=""
SortColumn:string="userLogAuditId"
SortOrder:string="desc";

}