export class ItemTypeModel {
  CategoryName: string;
}
