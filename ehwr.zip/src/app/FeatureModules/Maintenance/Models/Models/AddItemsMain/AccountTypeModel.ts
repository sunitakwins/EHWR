export class AccountTypeModel {
  categoryName: string;
}
