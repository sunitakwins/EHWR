export class UpdateEmployeesModel {
  EmployeeId: number;
  FirstName: string;
  SurName: number;
  ModifiedBy: string;
}

export class UpdateEmpStatusModel{
  EmployeeId : string;
  IsActive : boolean;
  ActionPerformedBy: string;
}
