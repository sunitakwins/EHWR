export class AddEmployeeModel {
  FirstName: string;
  SurName: string;
  CreatedBy: string;
}
