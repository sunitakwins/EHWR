export class UpdateEmployeesRequestModel {
  PageNo = -1;
  PageSize = 20;
}
