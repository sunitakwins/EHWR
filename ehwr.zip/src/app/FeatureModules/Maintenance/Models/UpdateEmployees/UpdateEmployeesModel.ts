export class UpdateEmployeesModel {
  EmployeeId: number;
  FirstName: string;
  SurName: string;
  IsActive : boolean
  ModifiedBy: string;
}
