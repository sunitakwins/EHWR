export class AddEmployeeModel {
  FirstName: string;
  SurName: string;
  IsActive : boolean
  CreatedBy: string;
}
