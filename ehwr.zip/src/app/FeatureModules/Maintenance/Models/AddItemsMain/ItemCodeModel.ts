export class ItemCodeModel {
  categoryId: number;
  categoryName: string;
  globalCodeCategoryDescription: string;
  globalCodeId: number;
  codeName: string;
  globalCodeDescription: string;
}
