import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ContentLayout',
  templateUrl: './ContentLayout.component.html',
  styleUrls: ['./ContentLayout.component.scss']
})
export class ContentLayoutComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
