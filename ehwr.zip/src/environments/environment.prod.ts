export const environment = {
  production: true,
  apiGateway: 'http://92.204.135.120:8084/api'
};
